<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Open Gift</title>
    <!-- Custom fonts for this template-->
    <link href="<?php echo base_url('assets/fontawesome-free/css/all.min.css'); ?>" rel="stylesheet" type="text/css">
    <!-- Page level plugin CSS-->
    <!-- <link href="<?php echo base_url('assets/datatables/dataTables.bootstrap4.css'); ?>" rel="stylesheet"> -->
    <!-- Custom styles for this template-->
    <link href="<?php echo base_url('css/sb-admin.css'); ?>" rel="stylesheet">
    <style>
        .zoom {
            transition: transform .2s; /* Animation */
        }
		.zoom:hover {
			transform: scale(1.1); /* (150% zoom - Note: if the zoom is too large, it will go outside of the viewport) */
		}
        ::-webkit-scrollbar {
            width: 6px; /* Lebar scrollbar */
            background-color: #f1f1f1; /* Warna latar belakang scrollbar */
        }

        /* Ubah warna scrollbar */
        ::-webkit-scrollbar-thumb {
            background-color: #888; /* Warna thumb scrollbar */
            border-radius: 4px; /* Bordes de scrollbar radius of */
        }
    </style>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Asap:ital,wght@0,100..900;1,100..900&family=Lilita+One&family=Roboto+Slab:wght@100..900&family=Rowdies:wght@300;400;700&display=swap" rel="stylesheet">
</head>
<?php
    $id_sesi = $this->input->get("sesi_id");
    if($id_sesi == "4"){
        $padding_top = "padding-top:13em;";
        $col = "col-lg-2";
    }else{
        $padding_top = "padding-top:13em;";
        $col = "col-lg-3";
    }
?>
<body class="text-center pl-3 pr-3 pt-4" style="overflow:hidden; margin-left:160px; margin-right:160px; background-color:#8775EF;">
	<a href="<?= base_url("open_sesi"); ?>" class="btn btn-sm btn-light" style="position:absolute; top:10px; right:10px;"><i class="fas fa-arrow-left pr-1"></i>Back</a>
    <div class="row justify-content-center p-3">
        <?php
        if(!empty($gift)){
            foreach ($gift as $gift) {
                if(!empty($gift->link_image)){
                    $image_gift = '<img src="'.base_url("assets/img_hadiah/".$gift->link_image.".png").'" width="90%">';
                }else{
                    $image_gift = '<img src="<?= base_url("assets/img_hadiah/icon_hadiah.png") ?>" width="30%">';
                }
                ?>
                <div class="<?= $col; ?> mb-3">
                    <a href="<?= base_url("rolling_gift?id_gift=".$gift->id."&sesi_id=".$gift->sesi); ?>" style="text-decoration:none;">
                        <div class="card zoom" style="background:rgba(255,255,255,30%); height:100%;">
                            <div class="card-body p-2 text-center text-dark">
                                <?= $image_gift; ?>
                                <h5 class="pb-2" style="font-family:Asap; font-weight:600;"><?= $gift->hadiah; ?></h5>
                            </div>
                        </div>
                    </a>
                </div>
                <?php
            }
        }
		?>
    </div>
</body>
</html>
<script src="<?php echo base_url('assets/jquery/jquery.min.js'); ?>"></script>
<script>
    $("#scan-id-card").focus();
    $("#scan-id-card").keyup(function(event) {
        // Check if key pressed is Enter (key code 13)
        if (event.keyCode === 13) {
            $.ajax({
                type:"post",
                url:"<?= base_url("simpan_absensi"); ?>",
                data:{
                    rfid:$(this).val()
                },
                dataType:"JSON",
                beforeSend:function() {
                    $(".result-scan").html("");
                    $("#npk").html('<i class="fas fa-spinner fa-spin"></i>');
                },
                success:function(r) {
                    d = JSON.parse(JSON.stringify(r));
                    if(d.status == 200){
                        $("#npk").html(d.npk);
                        $("#nama").html(d.nama);
                        $("#dept").html(d.dept);
                    }else{
                        $("#npk").html(d.res);
                    }
                    $("#scan-id-card").val("");
                    $("#scan-id-card").focus();
                },
                error:function(a,b,c) {
                    $("#npk").html(a.responseText);
                }
            }) 
        }
    });
</script>
