<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List Absensi</title>
    <!-- Custom fonts for this template-->
    <link href="<?php echo base_url('assets/fontawesome-free/css/all.min.css'); ?>" rel="stylesheet" type="text/css">
    <!-- Page level plugin CSS-->
	<link href="https://cdn.datatables.net/v/bs4/dt-2.1.8/fh-4.0.1/datatables.min.css" rel="stylesheet">
    <!-- Custom styles for this template-->
    <link href="<?php echo base_url('css/sb-admin.css'); ?>" rel="stylesheet">
    <style>
        .result-scan {
            -webkit-text-stroke-width: 3px;
            -webkit-text-stroke-color: black;
        }
        .card {
            background-color: rgba(255, 255, 255, 0.1); /* Warna latar belakang putih dengan 50% transparan */
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body class="text-center" style="background-color:#8775EF; padding-top:10em; background-image:url(<?= base_url("image/bgpemira.png"); ?>); background-size:100% 100%;">
	<a href="<?= base_url("absensi"); ?>" class="btn btn-sm btn-light" style="position:absolute; top:10px; right:10px;">Absensi</a>
    <div class="row justify-content-end">
		<div class="col-lg-9 pr-4">
			<div class="row">
				<div class="col-lg-6 pr-5">
					<canvas id="myDoughnutChart" style="width:200px; height:200px;"></canvas>
				</div>
				<div class="col-lg-6">
					<div class="card" style="background-color: rgba(255, 255, 255, 0.1);">
						<center><h3 class="text-light mb-4">KAP 1 & RnD</h3></center>
						<div class="card-body p-0">
							<table class="table table-bordered table-hover datatable">
								<thead>
									<tr>
										<th class="p-1 text-center text-light">No</th>
										<th class="p-1 text-center text-light">Dept</th>
										<th class="p-1 text-center text-light">Standard</th>
										<th class="p-1 text-center text-light">Actual</th>
										<th class="p-1 text-center text-light">Remain</th>
									</tr>
								</thead>
								<tbody>
									<?php
									$sudah_absen = 0;
									$belum_absen = 0;
									if(!empty($data_list_kap1)){
										$no = 1;
										foreach ($data_list_kap1 as $dlk1) {
											$act = $this->admin_model->gd("absen_peserta","COUNT(npk) as act","dept = ('".$dlk1->dept."')","row");
											$sudah_absen += $act->act;
											$belum_absen += ($act->act - $dlk1->std);
											if(($act->act - $dlk1->std) < 0){
												$bg = "bg-danger";
											}else{
												$bg = "bg-info";
											}
											?>
											<tr>
												<td style="font-size:8pt;" class="p-1 text-center text-light"><?= $no++; ?></td>
												<td style="font-size:8pt;" class="p-1 text-center text-light"><?= $dlk1->dept; ?></td>
												<td style="font-size:8pt;" class="p-1 text-center text-light"><?= $dlk1->std; ?></td>
												<td style="font-size:8pt;" class="p-1 text-center text-light"><?= $act->act; ?></td>
												<td style="font-size:8pt;" class="p-1 text-center text-light <?= $bg; ?>"><?= ($act->act - $dlk1->std); ?></td>
											</tr>
											<?php
										}
									}
									?>
								</tbody>
							</table>
						</div>
					</div>
					<div class="card mt-3" style="background-color: rgba(255, 255, 255, 0.1);">
						<center><h3 class="text-light mb-4">KAP 2</h3></center>
						<div class="card-body p-0">
							<table class="table table-bordered table-hover datatable">
								<thead>
									<tr>
										<th class="p-1 text-center text-light">No</th>
										<th class="p-1 text-center text-light">Dept</th>
										<th class="p-1 text-center text-light">Standard</th>
										<th class="p-1 text-center text-light">Actual</th>
										<th class="p-1 text-center text-light">Remain</th>
									</tr>
								</thead>
								<tbody>
									<?php
									if(!empty($data_list_kap2)){
										$no = 1;
										foreach ($data_list_kap2 as $dlk2) {
											$act = $this->admin_model->gd("absen_peserta","COUNT(npk) as act","dept = ('".$dlk2->dept."')","row");
											$sudah_absen += $act->act;
											$belum_absen += ($act->act - $dlk2->std);
											if(($act->act - $dlk2->std) < 0){
												$bg = "bg-danger";
											}else{
												$bg = "bg-info";
											}
											?>
											<tr>
												<td style="font-size:8pt;" class="p-1 text-center text-light"><?= $no++; ?></td>
												<td style="font-size:8pt;" class="p-1 text-center text-light"><?= $dlk2->dept; ?></td>
												<td style="font-size:8pt;" class="p-1 text-center text-light"><?= $dlk2->std; ?></td>
												<td style="font-size:8pt;" class="p-1 text-center text-light"><?= $act->act; ?></td>
												<td style="font-size:8pt;" class="p-1 text-center text-light <?= $bg; ?>"><?= ($act->act - $dlk2->std); ?></td>
											</tr>
											<?php
										}
									}
									?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
    </div>
</body>
</html>
<script src="<?php echo base_url('assets/jquery/jquery.min.js'); ?>"></script>
<script src="https://cdn.datatables.net/v/bs4/dt-2.1.8/fh-4.0.1/datatables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels"></script>
<script>
	$(".datatable").DataTable({
        scrollY: '230px', // Tinggi maksimal tabel
        scrollCollapse: true, // Mengaktifkan scroll jika tinggi tabel kurang dari scrollY
		fixedHeader: true,
		searching: false,
		paging: false,
		info: false,
	});
</script>

<script>
    // Get the canvas element
    var ctx = document.getElementById('myDoughnutChart').getContext('2d');

    // Create the doughnut chart
    var myDoughnutChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Belum Absen', 'Sudah Absen'],
            datasets: [{
                label: 'Colors',
                data: [<?= ($belum_absen * -1); ?>, <?= $sudah_absen; ?>],
                backgroundColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                ],
                borderWidth: 2
            }]
        },
        options: {
            plugins: {
                datalabels: {
                    color: '#fff',           // Warna teks (putih)
                    font: {
                        weight: 'bold',      // Berat font
                        size: 14             // Ukuran font
                    },
                    anchor: 'center',         // Posisi teks
                    align: 'center',          // Penyelarasan teks
                    formatter: (value, ctx) => {
                        let sum = 0;
                        let dataArr = ctx.chart.data.datasets[0].data;
                        dataArr.map(data => {
                            sum += data;
                        });
                        // Tampilkan persentase atau nilai
                        let percentage = (value * 100 / sum).toFixed(2) + "%"; 
                        return percentage;
                    }
                }
            },
            maintainAspectRatio: false
        }
    });

	setInterval(() => {
		window.location.reload();
	}, 10000);
</script>
