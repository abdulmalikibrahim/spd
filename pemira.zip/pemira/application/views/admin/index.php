<!DOCTYPE html>
<html lang="en">

<head>
    <?php $this->load->view('admin/head'); ?>
</head>

<body id="page-top">
    <!-- Navbar -->
    <?php $this->load->view('admin/navbar'); ?>
    <div id="wrapper">
        <!-- Sidebar -->
        <div id="content-wrapper">
            <div class="container-fluid">
                <!-- Breadcrumbs-->
                <div style="width: 100%; padding-bottom: 5px;" align="center">
                	<?php $info=$this->session->flashdata('info');
                		if (!empty($info))
                    	{
                      	echo $info;
                    	}
                	?>
            	</div>
                <!-- Area Chart Example-->
                <div class="card mb-3">
                    <div class="card-header">
                        <i class="fas fa-user-check"></i> ATTENDANCE
                    </div>
                    <div class="card-body" style="background-color: rgba(239, 255, 255, .5); min-height: 450px;">
                        <div class="row">
			    <div class="col-12">
			    	<form action="" method="get">
				    <div class="row">
				    	<div class="col-4">
					    <?php		
						$tanggal = $this->input->get("tanggal");
						if(empty($tanggal)){
	   					    $tanggal = date("Y-m-d");
						}else{
	   					    $tanggal = $tanggal;
						}
					    ?>
				    	    <input type="date" name="tanggal" class="form-control" value="<?= $tanggal ?>">
				    	</div>
					<div class="col-2">
					    <button class="btn btn-info">Submit</button>
					</div>
				    </div>
			    	</form>
			    </div>
                            <div class="col mt-2">
                                <div class="row">
                                    <div class="col-xl-6">
                                        <div class="card-body pl-0 pr-0 pt-0">
                                            <?php
                                            if(!empty($remain_kehadiran)){
                                                ?>
                                                <div class="row">
                                                    <?php
                                                    $no = 1;
                                                    foreach ($remain_kehadiran as $remain_kehadiran) {
                                                        ?>
                                                        <div class="col-4 mb-3">
                                                            <a href="javascript:void(0)" onclick="att('<?=$remain_kehadiran->NPK?>','<?=$remain_kehadiran->Nama?>')">
                                                                <div class="card h-100">
                                                                    <div class="card-body bg-info text-light" align="center">
                                                                        <h6><?=$remain_kehadiran->NPK?></h6>
                                                                        <h5><?=$remain_kehadiran->Nama?></h5>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                        <?php
                                                    }
                                                    ?>
                                                </div>
                                                <?php
                                            }
                                            ?>
                                        </div>
                                    </div>
                                    <div class="col-xl-6">
                                        <div class="card-header bg-success">
                                            <font style="color: white;">Status Kehadiran :</font>
                                        </div>
                                        <div class="card-body pl-0 pr-0">
                                            <?php
                                            if(!empty($data_kehadiran)){
                                                ?>
                                                <table class="table">
                                                    <thead class="thead-light">
                                                        <tr>
                                                            <th>No.</th>
                                                            <th>NPK</th>
                                                            <th>Nama</th>
                                                            <th>Status Kehadiran</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        $No = 1;
                                                        foreach ($data_kehadiran as $data_kehadiran) {
                                                            $where['NPK'] = $data_kehadiran->npk;
                                                            $nama = $this->admin_model->get_data_db_qebase('account',$where,'row');
                                                            ?>
                                                            <tr>
                                                                <td><?= $No++; ?></td>
                                                                <td><?= $data_kehadiran->npk; ?></td>
                                                                <td><?= $nama->Nama; ?></td>
                                                                <td><?= $data_kehadiran->status; ?></td>
                                                            </tr>
                                                            <?php
                                                        }
                                                        ?>
                                                    </tbody>
                                                </table>
                                                <?php
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php $this->load->view('admin/footer_copyright'); ?>
            </div>
            <!-- /.content-wrapper -->
        </div>
    </div>
    <div class="modal fade" id="modalhadir" tabindex="-1" role="dialog" aria-labelledby="modalhadirTitle" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalhadirTitle">Input Kehadiran</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="body-detail">
                <div class="row">
                    <div class="col-12 mb-2 font-weight-bold">Nama : <span id="span-nama"></span></div>
                    <?php
                    foreach ($data_attendance as $data_attendance) {
                        ?>
                        <div class="col-xl-3 col-md-4 col-sm-4 ">
                            <button class="<?= $data_attendance->button; ?> mt-2" id="<?= $data_attendance->name; ?>" data-status="<?=$data_attendance->status?>" data-point="<?=$data_attendance->point?>" onclick="proses('',,,)" style="width: 100%; height: 70px;"><i class="<?= $data_attendance->icon; ?>"></i> <?= $data_attendance->status; ?></button>
                        </div>
                        <?php
                    }
                    ?>
                </div>
                </div>
            </div>
        </div>
    </div>
    <?php $this->load->view('admin/footer_jquery'); ?>
</body>
</html>
<script type="text/javascript">
    function date_get_funct() {
        var get_month = document.getElementById('get_month');
        var get_year = document.getElementById('get_year');
        var date_get = document.getElementById('date_get');
        date_get.value = get_year.value+"-"+get_month.value+'-15';
    }

    function att(npk,nama) {
        $("#modalhadir").modal("show");
        $("#span-nama").html(nama);
        <?php
        $da = $this->admin_model->get_data('point_attendance',"id !=",'result');
        foreach ($da as $da) {
            ?>
            $("#<?=$da->name?>").attr("onclick","proses('<?=$da->status?>',<?=$da->point?>,"+npk+",'<?= $tanggal ?>')");
            <?php
        }
        ?>
    }

    function proses(status,point,npk,tanggal) {
        $.ajax({
            type:"get",
            url:"<?= base_url('index.php/admin/input_attendance'); ?>",
            data:{
                status:status,
                point:point,
                npk:npk,
                tanggal:tanggal,
            },
            success:function(r) {
                if(r === "sukses"){
                    location.reload();
                }else{
                    alert(r);
                }
            }
        })
    }
</script>