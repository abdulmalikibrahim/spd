<!DOCTYPE html>
<html lang="en">

<head>
    <?php $this->load->view('admin/head'); ?>
</head>

<body id="page-top">
    <!-- Navbar -->
    <?php $this->load->view('admin/navbar'); ?>
    <div id="wrapper">
        <!-- Sidebar -->
        <div id="content-wrapper">
            <div class="container-fluid">
                <!-- Breadcrumbs-->
                <div style="width: 100%; padding-bottom: 5px;" align="center">
                	<?php $info=$this->session->flashdata('info');
                		if (!empty($info))
                    	{
                      	echo $info;
                    	}
                	?>
            	</div>
                <!-- Area Chart Example-->
                <div class="card mb-3">
                    <div class="card-header">
                        <i class="fas fa-user-check"></i> ATTENDANCE
                    </div>
                    <div class="card-body" style="background-color: rgba(239, 255, 255, .5); min-height: 450px;">
                        <div class="row">
                            <div class="col">
                                <form method="post" action="<?= base_url('index.php/admin/input_attendance'); ?>">
                                    <font style="color: red; font-size: 10pt;">*Note : Jika terjadi kesalahan input, mohon informasi kepada admin.</font>
                                    <input type="number" class="form-control mt-2" name="npk" placeholder="NPK" style="text-align: center; font-size: 25pt;" required>
                                    <div class="row mt-2">
                                        <?php
                                        foreach ($data_attendance as $data_attendance) {
                                            ?>
                                            <div class="col-xl-2 col-md-4 col-sm-6">
                                                <button class="<?= $data_attendance->button; ?> mt-2" name="<?= $data_attendance->name; ?>" style="width: 100%; height: 70px;"><i class="<?= $data_attendance->icon; ?>"></i> <?= $data_attendance->status; ?></button>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col mt-2">
                                <div class="row">
                                    <div class="col-xl-6">
                                        <div class="card-header bg-warning">
                                            Remain Kehadiran :
                                        </div>
                                        <div class="card-body pl-0 pr-0">
                                            <?php
                                            if(!empty($remain_kehadiran)){
                                                ?>
                                                <table class="table">
                                                    <thead class="thead-light">
                                                        <tr>
                                                            <th>No.</th>
                                                            <th>NPK</th>
                                                            <th>Nama</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        $no = 1;
                                                        foreach ($remain_kehadiran as $remain_kehadiran) {
                                                            ?>
                                                            <tr>
                                                                <td><?= $no++ ?></td>
                                                                <td><?= $remain_kehadiran->NPK; ?></td>
                                                                <td><?= $remain_kehadiran->Nama; ?></td>
                                                            </tr>
                                                            <?php
                                                        }
                                                        ?>
                                                    </tbody>
                                                </table>
                                                <?php
                                            }
                                            ?>
                                        </div>
                                    </div>
                                    <div class="col-xl-6">
                                        <div class="card-header bg-success">
                                            <font style="color: white;">Status Kehadiran :</font>
                                        </div>
                                        <div class="card-body pl-0 pr-0">
                                            <?php
                                            if(!empty($data_kehadiran)){
                                                ?>
                                                <table class="table">
                                                    <thead class="thead-light">
                                                        <tr>
                                                            <th>No.</th>
                                                            <th>Nama</th>
                                                            <th>Status Kehadiran</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        $No = 1;
                                                        foreach ($data_kehadiran as $data_kehadiran) {
                                                            $where['NPK'] = $data_kehadiran->npk;
                                                            $nama = $this->admin_model->get_data_db_qebase('account',$where,'row');
                                                            ?>
                                                            <tr>
                                                                <td><?= $No++; ?></td>
                                                                <td><?= $nama->Nama; ?></td>
                                                                <td><?= $data_kehadiran->status; ?></td>
                                                            </tr>
                                                            <?php
                                                        }
                                                        ?>
                                                    </tbody>
                                                </table>
                                                <?php
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php $this->load->view('admin/footer_copyright'); ?>
            </div>
            <!-- /.content-wrapper -->
        </div>
    </div>
    <?php $this->load->view('admin/footer_jquery'); ?>
</body>
</html>
<script type="text/javascript">
    function date_get_funct() {
        var get_month = document.getElementById('get_month');
        var get_year = document.getElementById('get_year');
        var date_get = document.getElementById('date_get');
        date_get.value = get_year.value+"-"+get_month.value+'-15';
    }
</script>