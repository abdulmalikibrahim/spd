<nav class="navbar navbar-expand navbar-dark bg-dark static-top">

<a class="navbar-brand mr-1" href="index.html">ATTENDANCE</a>
<!-- Navbar Search -->
<form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
    <div class="input-group">
        
    </div>
</form>
<style>
  h1,h2,p,a{
    font-family: sans-serif;
    font-weight: normal;
  }

  .jam-digital-malasngoding {
    overflow: hidden;
    width: 100%;
    margin: 0px auto;
    border: 1px solid #efefef;
    border-radius: 15px;
    display: table;
  }
  .kotak{
    float: left;
    width: 30px;
    height: 30px;
  }
  .kotak_li{
    float: left;
    width: 30px;
    height: 30px;
    display: table-cell;
    text-align: center;
    padding-top: 3px;
    color: white;
  }
  .kotak_date{
    float: left;
    width: 180px;
    height: 30px;
  }
  .jam-digital-malasngoding p {
    color: #fff;
    font-size: 16px;
    text-align: center;
    margin-top: 5px;
  }
</style>
<script>
  window.setTimeout("waktu()", 1000);
  function waktu() {
    var waktu = new Date();
    setTimeout("waktu()", 1000);
    document.getElementById("jam").innerHTML = waktu.getHours()+" :";
    document.getElementById("menit").innerHTML = waktu.getMinutes()+" :";
    document.getElementById("detik").innerHTML = waktu.getSeconds();
  }
</script>
<ul class="navbar-nav ml-auto ml-md-0">
    <li class="nav-item dropdown no-arrow">
        <div class="jam-digital-malasngoding">
          <div class="kotak_li">
            <i class="fas fa-clock"></i>
          </div>
          <div class="kotak_date">
            <p id="date"><?= date('l, d F Y') ?></p>
          </div>
          <div class="kotak">
            <p id="jam"></p>
          </div>
          <div class="kotak">
            <p id="menit"></p>
          </div>
          <div class="kotak">
            <p id="detik"></p>
          </div>
        </div>
    </li>
    <li class="nav-item dropdown no-arrow">
        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color: white;">
            <?php echo $this->session->userdata('Nama_QEBase') ?>
            <i class="fas fa-user-circle fa-fw"></i>
        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal"><i class="fas fa-home"></i>&nbsp; Back Home</a>
        </div>
    </li>
</ul>
</nav>