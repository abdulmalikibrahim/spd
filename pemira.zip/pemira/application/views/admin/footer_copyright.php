
                <!-- Sticky Footer -->
                <footer class="sticky-footer" style="width: 100%;">
                    <div class="container my-auto">
                        <div class="copyright text-center my-auto">
                            <span>Created By Abdul Malik Ibrahim</span>
                        </div>
                    </div>
                </footer>