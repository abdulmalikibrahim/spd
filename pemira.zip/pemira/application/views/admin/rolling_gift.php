<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rolling Gift</title>
    <!-- Custom fonts for this template-->
    <link href="<?php echo base_url('assets/fontawesome-free/css/all.min.css'); ?>" rel="stylesheet" type="text/css">
    <!-- Page level plugin CSS-->
    <!-- <link href="<?php echo base_url('assets/datatables/dataTables.bootstrap4.css'); ?>" rel="stylesheet"> -->
    <!-- Custom styles for this template-->
    <link href="<?php echo base_url('css/sb-admin.css'); ?>" rel="stylesheet">
    <style>
        .zoom {
            transition: transform .2s; /* Animation */
        }
		.zoom:hover {
			transform: scale(1.1); /* (150% zoom - Note: if the zoom is too large, it will go outside of the viewport) */
		}
    </style>
    <style>
        /* Tambahkan animasi confetti ke dalam file CSS terpisah */
        @keyframes confetti-fall {
            0% {
                transform: translateY(-50vh) rotateZ(0deg);
                opacity: 1;
            }
            100% {
                transform: translateY(100vh) rotateZ(720deg);
                opacity: 0;
            }
        }

        .confetti-container {
            width: 100%;
            height: 100%;
            overflow: hidden;
            position: relative;
        }

        .confetti {
            width: 10px;
            height: 20px;
            background-color: #e74c3c; /* Warna confetti bisa disesuaikan */
            position: absolute;
            animation: confetti-fall linear infinite;
        }

        .confetti:nth-child(1) {
            left: 5%;
            animation-duration: 4s; /* Durasi jatuh bisa disesuaikan */
        }

        .confetti:nth-child(2) {
            left: 15%;
            animation-duration: 3s; /* Durasi jatuh bisa disesuaikan */
        }

        .confetti:nth-child(3) {
            left: 25%;
            animation-duration: 5s; /* Durasi jatuh bisa disesuaikan */
        }

        .confetti:nth-child(4) {
            left: 35%;
            animation-duration: 4s; /* Durasi jatuh bisa disesuaikan */
        }

        .confetti:nth-child(5) {
            left: 45%;
            animation-duration: 3s; /* Durasi jatuh bisa disesuaikan */
        }
    </style>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lilita+One&family=Roboto+Slab:wght@100..900&family=Rowdies:wght@300;400;700&display=swap" rel="stylesheet">
</head>
<body class="text-center pl-3 pr-3 pt-4" style="overflow:hidden; margin-left:160px; margin-right:160px; background-color:#8775EF;">
    <a href="<?= base_url("open_sesi"); ?>" class="btn btn-sm btn-light" style="position:absolute; top:10px; right:10px;"><i class="fas fa-home pr-1"></i>Home</a>
    <div class="row justify-content-center">
        <?php
        if($gift->link_image != "4"){
            ?>
            <h3 class="text-light" style="font-family:Lilita One;font-weight-bold:300; font-size:4rem; position: absolute; top: 3rem;">DOORPRIZE</h3>
            <?php
        }else{
            ?>
            <h3 class="text-light" style="font-family:Lilita One;font-weight-bold:300; font-size:4rem; position: absolute; top: 5rem;">GRAND PRIZE</h3>
            <?php
        }
        if(!empty($gift->link_image)){
            ?>
            <div class="col-lg-12 text-center" style="margin-top:5em;">
                <img src="<?= base_url("assets/img_hadiah/".$gift->link_image.".png"); ?>" width="35%">
            </div>
            <div class="col-lg-12 text-center mb-2">
                <h3 class="text-light" style="font-family:Lilita One;font-weight-bold:300; margin-top:-1rem;"><?= $gift->hadiah." (Kuota : ".$gift->kuota.")"; ?></h3>
            </div>
            <?php
        }else{
            ?>
            <div class="col-lg-12 text-right mb-1">
                <h3 class="text-light" style="font-family:Lilita One;font-weight-bold:300; margin-top:9rem;"><?= $gift->hadiah." (Kuota : ".$gift->kuota.")"; ?></h3>
            </div>
            <?php
        }
        
		if(!empty($gift->kuota)){
            if(!empty($pemenang_fixed)){
                if($gift->kuota > 20){
                    $i = 0;
                    foreach ($pemenang_fixed as $pf) {
                        ?>
                        <div class="col-lg-2 mb-2">
                            <div class="card zoom" style="background:rgba(255,255,255,60%); cursor:pointer; height:100%;">
                                <div class="card-body p-1 text-center text-dark">
                                    <h3 style="font-size:15pt; font-family:Lilita One; font-weight:500;" class="m-0 rolling-npk" id="rolling-npk-<?= $i; ?>"><?= $pf->npk; ?></h3>
                                    <div style="font-size:5pt; overflow:hidden; font-family:Rowdies; font-weight:300;" class="m-0 rolling-nama" id="rolling-nama-<?= $i; ?>"><?= $pf->nama; ?></div>
                                </div>
                            </div>
                        </div>
                        <?php
                        $i++;
                    }
                }else{
                    $i = 0;
                    foreach ($pemenang_fixed as $pf) {
                        ?>
                        <div class="col-lg-2 mb-3">
                            <div class="card zoom" style="background:rgba(255,255,255,60%); cursor:pointer; height:100%;">
                                <div class="card-body p-1 text-center text-dark">
                                    <h3 style="font-size:25pt; font-family:Lilita One; font-weight:500;" class="m-0 rolling-npk" id="rolling-npk-<?= $i; ?>"><?= $pf->npk; ?></h3>
                                    <div style="font-size:7pt; overflow:hidden; font-family:Rowdies; font-weight:300;" class="m-0 rolling-nama" id="rolling-nama-<?= $i; ?>"><?= $pf->nama; ?></div>
                                </div>
                            </div>
                        </div>
                        <?php
                        $i++;
                    }
                }
            }else{
                if($gift->kuota > 20){
                    for ($i=0; $i < $gift->kuota ; $i++) { 
                        ?>
                        <div class="col-lg-2 mb-2">
                            <div class="card zoom" style="background:rgba(255,255,255,60%); cursor:pointer;">
                                <div class="card-body p-1 text-center text-dark">
                                    <div class="row" style="height: 0px !important;">
                                        <div class="col-12 text-right pr-3">
                                            <a href="javascript:void(0)" style="text-decoration:none; font-size:8pt;" class="text-success" title="Rolling Ulang" id="rolling-ulang-<?=$i?>" onclick="rolling_one(<?= $i; ?>)"><i class="fas fa-play"></i></a>
                                        </div>
                                    </div>
                                    <h3 style="font-size:15pt; font-family:Lilita One; font-weight:500;" class="m-0 rolling-npk" id="rolling-npk-<?= $i; ?>">000000</h3>
                                    <div style="font-size:5pt; overflow:hidden; font-family:Rowdies; font-weight:300;" class="m-0 rolling-nama" id="rolling-nama-<?= $i; ?>">000000</div>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                }else{
                    if($gift->kuota == "6"){
                        ?>
                    </div>
                        <div class="row justify-content-center">
                            <?php
                            for ($i=0; $i < 3 ; $i++) { 
                                ?>
                                <div class="col-lg-2 mb-3">
                                    <div class="card zoom" style="background:rgba(255,255,255,60%); cursor:pointer;">
                                        <div class="card-body p-1 text-center text-dark">
                                            <div class="row" style="height: 0px !important;">
                                                <div class="col-12 text-right pr-3">
                                                    <a href="javascript:void(0)" style="text-decoration:none; font-size:8pt;" class="text-success" title="Rolling Ulang" id="rolling-ulang-<?=$i?>" onclick="rolling_one(<?= $i; ?>)"><i class="fas fa-play"></i></a>
                                                </div>
                                            </div>
                                            <h3 style="font-size:25pt; font-family:Lilita One; font-weight:500;" class="m-0 rolling-npk" id="rolling-npk-<?= $i; ?>">000000</h3>
                                            <div style="font-size:7pt; overflow:hidden; font-family:Rowdies; font-weight:300;" class="m-0 rolling-nama" id="rolling-nama-<?= $i; ?>">000000</div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
                            ?>
                        </div>
                        <div class="row justify-content-center">
                            <?php
                            for ($i=3; $i < 6 ; $i++) { 
                                ?>
                                <div class="col-lg-2 mb-3">
                                    <div class="card zoom" style="background:rgba(255,255,255,60%); cursor:pointer;">
                                        <div class="card-body p-1 text-center text-dark">
                                            <div class="row" style="height: 0px !important;">
                                                <div class="col-12 text-right pr-3">
                                                    <a href="javascript:void(0)" style="text-decoration:none; font-size:8pt;" class="text-success" title="Rolling Ulang" id="rolling-ulang-<?=$i?>" onclick="rolling_one(<?= $i; ?>)"><i class="fas fa-play"></i></a>
                                                </div>
                                            </div>
                                            <h3 style="font-size:25pt; font-family:Lilita One; font-weight:500;" class="m-0 rolling-npk" id="rolling-npk-<?= $i; ?>">000000</h3>
                                            <div style="font-size:7pt; overflow:hidden; font-family:Rowdies; font-weight:300;" class="m-0 rolling-nama" id="rolling-nama-<?= $i; ?>">000000</div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
                            ?>
                        </div>
                        <?php
                    }else{
                        for ($i=0; $i < $gift->kuota ; $i++) { 
                            ?>
                            <div class="col-lg-3 mb-3">
                                <div class="card zoom" style="background:rgba(255,255,255,60%); cursor:pointer;">
                                    <div class="card-body p-1 text-center text-dark">
                                        <div class="row" style="height: 0px !important;">
                                            <div class="col-12 text-right pr-3">
                                                <a href="javascript:void(0)" style="text-decoration:none; font-size:8pt;" class="text-success" title="Rolling Ulang" id="rolling-ulang-<?=$i?>" onclick="rolling_one(<?= $i; ?>)"><i class="fas fa-play"></i></a>
                                            </div>
                                        </div>
                                        <h3 style="font-size:20pt; font-family:Lilita One; font-weight:500;" class="m-0 rolling-npk" id="rolling-npk-<?= $i; ?>">000000</h3>
                                        <div style="font-size:7pt; overflow:hidden; font-family:Rowdies; font-weight:300;" class="m-0 rolling-nama" id="rolling-nama-<?= $i; ?>">000000</div>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }
                    }
                }
            }
            
		}

        $next_id = $this->admin_model->gd("master_hadiah","id,sesi","id > '".$this->input->get("id_gift")."' ORDER BY id ASC","row");
        if(!empty($next_id)){
            $next_id_gift = $next_id->id;
            $next_id_sesi = $next_id->sesi;
        }else{
            $next_id_gift = 0;
            $next_id_sesi = 0;
        }

        $back_id = $this->admin_model->gd("master_hadiah","id,sesi","id < '".$this->input->get("id_gift")."' ORDER BY id DESC","row");
        if(!empty($back_id)){
            $back_id_gift = $back_id->id;
            $back_id_sesi = $back_id->sesi;
        }else{
            $back_id_gift = 0;
            $back_id_sesi = 0;
        }
		?>
        <div class="col-lg-12 text-right" style="position:absolute; bottom:10px; right:130px;">
            <?php
            if(!empty($back_id_gift) && !empty($back_id_sesi)){
                ?>
                <a href="<?= base_url("rolling_gift?id_gift=".$back_id->id."&sesi_id=".$back_id->sesi); ?>" class="btn btn-sm btn-warning" onclick="show_loading('Back Page...')"><i class="fas fa-arrow-left pr-1"></i>Back</a>
                <?php
            }
            ?>
            <a href="javascript:void(0)" class="btn btn-sm btn-light" id="btn-rolling" onclick="rolling()"><i class="fas fa-play pr-2"></i>Start</a>
            <a href="<?= base_url("save_pemenang?id_gift=".$this->input->get("id_gift")."&sesi_id=".$this->input->get("sesi_id")); ?>" class="btn btn-sm btn-success" onclick="show_loading('Saving Data...')"><i class="fas fa-save pr-1"></i>Save</a>
            <?php
            if(!empty($next_id_gift) && !empty($next_id_sesi)){
                ?>
                <a href="<?= base_url("rolling_gift?id_gift=".$next_id->id."&sesi_id=".$next_id->sesi); ?>" class="btn btn-sm btn-warning" onclick="show_loading('Next Page...')"><i class="fas fa-arrow-right pr-1"></i>Next</a>
                <?php
            }
            ?>
        </div>
    </div>
    <div class="w-100 text-center" style="height:100vh; background:rgba(0,0,0,0.5); position:absolute; top:0; right:0; display:flex; justify-content:center; align-items:center; flex-direction:column;" id="loading">
        <i class="fas fa-spinner fa-spin text-light" style="font-size:5em;"></i>
        <label style="font-family:Lilita One; font-size:3rem;" class="text-light" id="label-loading">Saving Data...</label>
    </div>
    <button id="play-sound" hidden>Play</button>
    <button id="stop-sound" hidden>Stop</button>
</body>
</html>
<script src="<?php echo base_url('assets/jquery/jquery.min.js'); ?>"></script>
<script>
        // Buat AudioContext
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();

        // Muat dan decode audio file
        async function loadSound(url) {
            const response = await fetch(url);
            const arrayBuffer = await response.arrayBuffer();
            return audioContext.decodeAudioData(arrayBuffer);
        }

        // Play sound effect
        function playSound(buffer) {
            const source = audioContext.createBufferSource();
            source.buffer = buffer;
            source.connect(audioContext.destination);
            source.start();
            return source; // Kembalikan source untuk dapat dihentikan nanti
        }

        // Load sound effect
        let soundBuffer;
        loadSound('<?= base_url("assets/soundeffect.wav"); ?>').then(buffer => {
            soundBuffer = buffer;
        });

        let timeoutId; // Untuk menyimpan ID timeout

        // Mulai pemutaran
        function startPlaying() {
            if (soundBuffer) {
                const interval = 0.1;
                function loopPlaySound() {
                    playSound(soundBuffer);
                    timeoutId = setTimeout(loopPlaySound, interval * 1000);
                }
                loopPlaySound();
            } else {
                console.error('Sound buffer is not loaded yet.');
            }
        }

        // Hentikan pemutaran
        function stopPlaying() {
            clearTimeout(timeoutId);
            timeoutId = null; // Reset timeoutId
            // Jika ada audio yang sedang diputar, hentikan dengan cara berikut:
            // (Jika Anda menggunakan AudioBufferSourceNodes di luar dari contoh ini, Anda harus melacak dan menghentikan setiap node)
            // audioContext.close(); // Ini akan menghentikan semua pemutaran audio
        }

        // Event listeners
        document.getElementById('play-sound').addEventListener('click', startPlaying);
        document.getElementById('stop-sound').addEventListener('click', stopPlaying);

</script>
<script>
    $("#loading").hide();
    function show_loading(label = null) {
        $("#loading").show();
        if(label){
            $("#label-loading").html(label);
        }
    }
    var base_url = "<?= base_url(); ?>";
    var intervalRolling;
    function rolling() {
        $("#play-sound").trigger("click");
        var peserta_rolling = <?= json_encode($peserta_rolling); ?>;
        // Mengacak indeks dari array peserta_rolling
        intervalRolling = setInterval(() => {
            var randomIndex = Math.floor(Math.random() * peserta_rolling.length);
            
            // Mengambil data peserta yang terpilih secara acak
            var pesertaTerpilih = peserta_rolling[randomIndex];
            
            // Menampilkan hasil rolling di console
            $(".rolling-npk").html(pesertaTerpilih.npk);
            $(".rolling-nama").html(pesertaTerpilih.nama);
        }, 10);
        $("#btn-rolling").attr("onclick","stop_rolling()");
        $("#btn-rolling").html('<i class="fas fa-stop pr-2"></i>Stop');
    }

    function stop_rolling() {
        $("#stop-sound").trigger("click");
        var list_pemenang = <?= json_encode($pemenang); ?>;
        console.log(list_pemenang);
        list_pemenang.forEach(function(val,index) {
            $("#rolling-npk-"+index).html(val.npk);
            $("#rolling-nama-"+index).html(val.nama);
        });
        $("#btn-rolling").attr("onclick","rolling()");
        $("#btn-rolling").html('<i class="fas fa-play pr-2"></i>Start');
        clearInterval(intervalRolling);
    }

    var intervalRollingOne;
    var peserta_rolling_one = <?= json_encode($peserta_rolling); ?>;
    function rolling_one(id,stop = false) {
        var npk = $("#rolling-npk-"+id).html();
        // Mengacak indeks dari array peserta_rolling_one
        if(stop == true){
            $("#stop-sound").trigger("click");
            $("#rolling-ulang-"+id).removeClass('text-danger');
            $("#rolling-ulang-"+id).addClass('text-success');
            $("#rolling-ulang-"+id).attr("onclick","rolling_one("+id+")");
            clearInterval(intervalRollingOne);
            $("#rolling-ulang-"+id).html('<i class="fas fa-play"></i>');
            rolling_one_id = sessionStorage.getItem('rolling_one');
            peserta_rolling_one.splice(rolling_one_id,1);
            $.ajax({
                type:"get",
                url:base_url+"/setup_pemenang_one",
                data:{
                    npk:npk,
                    id_gift:'<?= $this->input->get("id_gift"); ?>',
                    sesi_id:'<?= $this->input->get("sesi_id"); ?>',
                },
                dataType:"JSON",
                success:function(r) {
                    d = JSON.parse(JSON.stringify(r));
                    console.log(d);
                },
                error:function(a,b,c) {
                    console.log(a.responseText);
                }
            });
            sessionStorage.removeItem('rolling_one');
        }

        if(stop == false){
            $("#play-sound").trigger("click");
            $("#rolling-ulang-"+id).removeClass('text-success');
            $("#rolling-ulang-"+id).addClass('text-danger');
            //DELETE DATA PEMENANG 
            $.ajax({
                type:"get",
                url:base_url+"/delete_winner",
                data:{
                    npk:npk,
                },
                dataType:"JSON",
                success:function(r) {
                    d = JSON.parse(JSON.stringify(r));
                    console.log(d);
                },
                error:function(a,b,c) {
                    console.log(a.responseText);
                }
            });
            intervalRollingOne = setInterval(() => {
                var randomIndex = Math.floor(Math.random() * peserta_rolling_one.length);
                
                // Mengambil data peserta yang terpilih secara acak
                var pesertaTerpilih = peserta_rolling_one[randomIndex];
                
                // Menampilkan hasil rolling di console
                $("#rolling-npk-"+id).html(pesertaTerpilih.npk);
                $("#rolling-nama-"+id).html(pesertaTerpilih.nama);
                sessionStorage.setItem('rolling_one',randomIndex);
            }, 15);
            $("#rolling-ulang-"+id).attr("onclick","rolling_one("+id+",true)");
            $("#rolling-ulang-"+id).html('<i class="fas fa-stop"></i>');
        }
    }
</script>
