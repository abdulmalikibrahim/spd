<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Open Sesi</title>
    <!-- Custom fonts for this template-->
    <link href="<?php echo base_url('assets/fontawesome-free/css/all.min.css'); ?>" rel="stylesheet" type="text/css">
    <!-- Page level plugin CSS-->
    <!-- <link href="<?php echo base_url('assets/datatables/dataTables.bootstrap4.css'); ?>" rel="stylesheet"> -->
    <!-- Custom styles for this template-->
    <link href="<?php echo base_url('css/sb-admin.css'); ?>" rel="stylesheet">
    <style>
        .zoom {
            transition: transform .2s; /* Animation */
        }
		.zoom:hover {
			transform: scale(1.1); /* (150% zoom - Note: if the zoom is too large, it will go outside of the viewport) */
		}
    </style>
</head>
<body class="text-center pl-3 pr-3 pt-4" style="overflow:hidden; margin-left:160px; margin-right:160px; background-color:#8775EF;">
	<div style="position:absolute; top:10px; right:10px;">
        <a href="<?= base_url("absensi"); ?>" class="btn btn-sm btn-light">Back</a>
    </div>
    <div class="row justify-content-center">
        <?php
		if(!empty($sesi)){
			foreach ($sesi as $sesi) {
				?>
				<div class="col-lg-2 mt-5">
					<a href="<?= base_url("open_gift?sesi_id=".$sesi->id); ?>" style="text-decoration:none;">
						<div class="card zoom" style="background:rgba(255,255,255,60%);">
							<div class="card-body text-center text-dark">
								<img src="<?= base_url("assets/img_hadiah/icon_hadiah.png") ?>" width="50%">
								<h4><?= $sesi->sesi_name; ?></h4>
							</div>
						</div>
					</a>
				</div>
				<?php
			}
		}
		?>
    </div>
</body>
</html>
