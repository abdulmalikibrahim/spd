<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Absensi</title>
    <!-- Custom fonts for this template-->
    <link href="<?php echo base_url('assets/fontawesome-free/css/all.min.css'); ?>" rel="stylesheet" type="text/css">
    <!-- Page level plugin CSS-->
    <!-- <link href="<?php echo base_url('assets/datatables/dataTables.bootstrap4.css'); ?>" rel="stylesheet"> -->
    <!-- Custom styles for this template-->
    <link href="<?php echo base_url('css/sb-admin.css'); ?>" rel="stylesheet">
    <style>
        .result-scan {
            -webkit-text-stroke-width: 3px;
            -webkit-text-stroke-color: black;
        }
        .card {
            background-color: rgba(255, 255, 255, 0.1); /* Warna latar belakang putih dengan 50% transparan */
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }
        .transparent-textbox {
            background-color: rgba(255, 255, 255, 0.1); /* Latar belakang putih dengan 50% transparan */
            color: #fff; /* Warna teks tetap hitam */
            border: 1px solid #ccc; /* Border agar tetap terlihat */
            padding: 10px;
            border-radius: 5px;
            font-size: 16px;
        }
        .transparent-textbox::placeholder {
            color: #999; /* Warna teks placeholder agar berbeda */
        }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Lilita+One&family=Roboto+Slab:wght@100..900&family=Rowdies:wght@300;400;700&display=swap" rel="stylesheet">
</head>
<body class="text-center pl-3 pr-3" style="margin-left:15rem; margin-right:-8rem; background-color:#8775EF; padding-top:20em; background-image:url(<?= base_url("image/bgpemira.png"); ?>); background-size:100% 100%;">
    <h3 class="text-light" style="font-family:Lilita One;font-weight-bold:300; font-size:4rem; position: absolute; top: 13rem; left:50rem;">ABSENSI PESERTA</h3>
    <div style="position:absolute; top:10px; right:10px;">
        <a href="<?= base_url("list_absensi"); ?>" class="btn btn-sm btn-light">Lihat Absensi</a>
    </div>
    <div class="row justify-content-center">
        <div class="col-lg-5">
            <input type="text" class="text-center transparent-textbox" id="scan-id-card" style="font-size:30pt; font-family:calibri; border-color:#FFFFFF;" placeholder="Masukkan NPK">
        </div>
    </div>
    <div class="row justify-content-center mt-5">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body">
                    <div class="font-weight-bold text-light result-scan" style="font-size:50pt; font-family:calibri; line-height:100%;" id="npk">NPK</div>
                    <div class="font-weight-bold text-light result-scan" style="font-size:50pt; font-family:calibri; line-height:100%;" id="nama">NAMA</div>
                    <div class="font-weight-bold text-light result-scan" style="font-size:50pt; font-family:calibri; line-height:100%;" id="dept">DEPT</div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<script src="<?php echo base_url('assets/jquery/jquery.min.js'); ?>"></script>
<script>
    $("#scan-id-card").focus();
    let timeoutId;
    
    $("#input-npk").keyup(function(event) {
        if (event.keyCode === 13) {
            $.ajax({
                type:"post",
                url:"<?= base_url("simpan_absensi_npk"); ?>",
                data:{
                    npk:$("#input-npk").val()
                },
                dataType:"JSON",
                beforeSend:function() {
                    $(".result-scan").html("");
                    $("#npk").html('<i class="fas fa-spinner fa-spin"></i>');
                },
                success:function(r) {
                    d = JSON.parse(JSON.stringify(r));
                    if(d.status == 200){
                        $("#npk").html(d.npk);
                        $("#nama").html(d.nama);
                        $("#dept").html(d.dept);
                    }else{
                        $("#npk").html(d.res);
                    }
                    $("#input-npk").val("");
                    $("#scan-id-card").focus();
                },
                error:function(a,b,c) {
                    $("#npk").html(a.responseText);
                }
            });
        }
    });
    $("#scan-id-card").keyup(function(event) {
        // Clear timeout sebelumnya (jika ada)
        clearTimeout(timeoutId);
        // Check if key pressed is Enter (key code 13)
        timeoutId = setTimeout(function() {
            $(".result-scan").html("");
            $("#npk").html('<i class="fas fa-spinner fa-spin"></i>');
            $.ajax({
                type:"post",
                url:"<?= base_url("simpan_absensi"); ?>",
                data:{
                    rfid:$("#scan-id-card").val()
                },
                dataType:"JSON",
                success:function(r) {
                    d = JSON.parse(JSON.stringify(r));
                    if(d.status == 200){
                        $("#npk").html(d.npk);
                        $("#nama").html(d.nama);
                        $("#dept").html(d.dept);
                    }else{
                        $("#npk").html(d.res);
                    }
                    $("#scan-id-card").val("");
                    $("#scan-id-card").focus();
                },
                error:function(a,b,c) {
                    $("#npk").html(a.responseText);
                }
            });
        }, 500);
        if (event.keyCode === 13) {
            $.ajax({
                type:"post",
                url:"<?= base_url("simpan_absensi"); ?>",
                data:{
                    rfid:$("#scan-id-card").val()
                },
                dataType:"JSON",
                beforeSend:function() {
                    $(".result-scan").html("");
                    $("#npk").html('<i class="fas fa-spinner fa-spin"></i>');
                },
                success:function(r) {
                    d = JSON.parse(JSON.stringify(r));
                    if(d.status == 200){
                        $("#npk").html(d.npk);
                        $("#nama").html(d.nama);
                        $("#dept").html(d.dept);
                    }else{
                        $("#npk").html(d.res);
                    }
                    $("#scan-id-card").val("");
                    $("#scan-id-card").focus();
                },
                error:function(a,b,c) {
                    $("#npk").html(a.responseText);
                }
            });
        }
    });
</script>
