<?php

error_reporting();
class admin extends CI_Controller {
    function fb($array)
    {
        echo json_encode($array);
        die();   
    }
	function index()
    {
        $this->load->view("admin/absensi");
    }
	function absensi()
    {
        $this->load->view("admin/absensi");
    }
	function open_sesi()
    {
		$data["sesi"] = $this->admin_model->get_data("sesi","id !=","result");
        $this->load->view("admin/open_sesi",$data);
    }
    function open_gift() {
        if(!empty($this->input->get("sesi_id"))){
            $data["gift"] = $this->admin_model->get_data("master_hadiah","sesi = '".$this->input->get("sesi_id")."'","result");
            $this->load->view("admin/open_gift",$data);
        }else{
            reidrect("open_sesi");
        }
    }
	function list_absensi()
    {
		$data_list_kap1 = $this->admin_model->gd("master_peserta","dept,COUNT(npk) as std","npk != '' AND status = 'KAP1' GROUP BY dept ORDER BY dept ASC","result");
		$data_list_kap2 = $this->admin_model->gd("master_peserta","dept,COUNT(npk) as std","npk != '' AND status = 'KAP2' GROUP BY dept ORDER BY dept ASC","result");
		$data["data_list_kap1"] = $data_list_kap1;
		$data["data_list_kap2"] = $data_list_kap2;
        $this->load->view("admin/list_absensi",$data);
    }
    function simpan_absensi()
    {
        $this->form_validation->set_rules("rfid","NPK","integer|required|trim");
        if($this->form_validation->run() === FALSE){
            $fb = ["status" => 500, "res" => validation_errors()];
            $this->fb($fb);
        }

        $rfid = $this->input->post("rfid");
        //CARI RFID
        $validasi = $this->admin_model->get_data("master_peserta","rfid = '$rfid'","row");
        if(!empty($validasi)){
            $fb = ["status" => 200, "npk" => $validasi->npk, "nama" => strtoupper($validasi->nama), "dept" => strtoupper($validasi->dept)];
            //CHECK ABSENSI
            $check = $this->admin_model->get_data("absen_peserta","npk = '".$validasi->npk."'","row");
            if(empty($check)){
                //INPUT ABSENSI
                $data_submit = ["npk" => $validasi->npk, "nama" => $validasi->nama, "dept" => $validasi->dept, "status" => $validasi->status];
                $this->admin_model->insert("absen_peserta",$data_submit);
            }else{
                $fb = ["status" => 500, "res" => "Can't input double"];
            }
        }else{
            $fb = ["status" => 500, "res" => "Data karyawan tidak ditemukan"];
        }
        $this->fb($fb);
    }
	function sesi()
    {
        $this->load->view("sesi");
    }
    function setup_pemenang_one()
    {
        $npk = $this->input->get("npk");
        $hadiah = $this->input->get("id_gift");
        $sesi = $this->input->get("sesi_id");
        //GET DATA MASTER
        $employee = $this->admin_model->gd("master_peserta","nama,dept","npk = '$npk'","row");
        //INSERT TO DATA PEMENANG
        $data_submit = ["npk" => $npk, "nama" => $employee->nama, "dept" => $employee->dept, "sesi" => $sesi, "hadiah" => $hadiah];
        $this->admin_model->insert("pemenang_temp",$data_submit);
        
        //DELETE DATA ROLLING
        $this->admin_model->delete("peserta_rolling","npk = '$npk'");
        $fb = ["status" => 200, "res" => "delete winner"];
        $this->fb($fb);
    }
    function delete_winner()
    {
        $npk = $this->input->get("npk");
        //DELETE DATA PEMENANG
        $this->admin_model->delete("pemenang_temp","npk = '$npk'");
        //DELETE DATA ROLLING
        $this->admin_model->delete("peserta_rolling","npk = '$npk'");
        $fb = ["status" => 200, "res" => "delete winner"];
        $this->fb($fb);
    }
    function save_pemenang()
    {
        $id_gift = $this->input->get("id_gift");
        $sesi_id = $this->input->get("sesi_id");
        $update = [
            "fixed" => "Yes",
        ];
        $data_temp = $this->admin_model->update_data("sesi = '$sesi_id' AND hadiah = '$id_gift'",$update,"pemenang_temp");
        redirect("rolling_gift?id_gift=".$id_gift."&sesi_id=".$sesi_id);  
    }
}
