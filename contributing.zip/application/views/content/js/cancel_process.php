<script>
	$("#scan").focus();
	$("#form-processing").submit(function() {
		$("#btn-scan").html('<i class="fas fa-spinner fa-spin"></i> PROCESSING...');
	});
</script>
